import test from 'node:test';
import assert from 'node:assert/strict';

import { buildAiChatPlan } from '../server/src/skills/ai-chat.js';
import { buildGenericMediaPlaybackPlan } from '../server/src/skills/generic-media.js';
import { buildLiveEntryPlan } from '../server/src/skills/live-entry.js';
import { buildMeetingLinkPlan } from '../server/src/skills/meeting-link.js';
import { buildShortVideoPlan } from '../server/src/skills/short-video.js';
import { buildWechatChannelsPlan } from '../server/src/skills/wechat-channels.js';

const screen = { width: 1260, height: 2800 };

test('generic media playback taps into content and player area', () => {
  const plan = buildGenericMediaPlaybackPlan({
    app: { name: 'B站', packageName: 'tv.danmaku.bili' },
    durationMs: 10_000,
    screen,
  });

  assert.ok(plan.some((step) => step.type === 'launch_app'));
  assert.ok(plan.some((step) => step.type === 'assert_no_sensitive_prompt'));
  assert.ok(plan.some((step) => step.type === 'tap' && step.label.includes('内容')));
  assert.ok(plan.some((step) => step.type === 'tap' && step.label.includes('播放')));
  assert.ok(plan.some((step) => step.type === 'assert_foreground_package'));
  assert.ok(plan.some((step) => step.type === 'assert_screen_changes'));
});

test('WeChat Channels plan uses text navigation before feed swipes', () => {
  const plan = buildWechatChannelsPlan({
    app: { name: '微信', packageName: 'com.tencent.mm' },
    durationMs: 20_000,
    screen,
  });

  assert.ok(plan.some((step) => step.type === 'tap_text' && step.texts.includes('发现')));
  assert.ok(plan.some((step) => step.type === 'assert_no_sensitive_prompt'));
  assert.ok(plan.some((step) => step.type === 'tap_text' && step.texts.includes('视频号')));
  assert.ok(plan.some((step) => step.type === 'assert_foreground_package'));
  assert.ok(plan.some((step) => step.type === 'assert_screen_changes'));
  assert.ok(plan.some((step) => step.type === 'swipe'));
});

test('XHS short video plan enters video feed before swiping', () => {
  const plan = buildShortVideoPlan({
    app: { id: 'xiaohongshu', name: '小红书', packageName: 'com.xingin.xhs' },
    durationMs: 12_000,
    screen,
  });

  const videoStepIndex = plan.findIndex(
    (step) => step.type === 'tap_text' && step.texts.includes('视频') && step.partial,
  );
  const firstSwipeIndex = plan.findIndex((step) => step.type === 'swipe');

  assert.ok(plan.some((step) => step.type === 'force_stop' && step.packageName === 'com.xingin.xhs'));
  assert.ok(videoStepIndex > -1);
  assert.ok(plan.some((step) => step.type === 'assert_ui_text' && step.label.includes('小红书')));
  assert.ok(plan.some((step) => step.type === 'assert_screen_changes'));
  assert.ok(firstSwipeIndex > videoStepIndex);
});

test('Douyin short video plan skips image posts before watching', () => {
  const plan = buildShortVideoPlan({
    app: { id: 'douyin', name: '抖音', packageName: 'com.ss.android.ugc.aweme' },
    durationMs: 12_000,
    screen,
  });

  assert.ok(plan.some((step) => step.type === 'swipe_while_ui_text_matches'));
  assert.ok(plan.some((step) => step.type === 'assert_screen_changes'));
});

test('live entry plan opens live tab and browses passively', () => {
  const plan = buildLiveEntryPlan({
    app: { name: '微博', packageName: 'com.sina.weibo' },
    durationMs: 30_000,
    screen,
  });

  assert.ok(plan.some((step) => step.type === 'tap_text' && step.texts.includes('直播')));
  assert.ok(plan.some((step) => step.type === 'assert_no_sensitive_prompt'));
  assert.ok(plan.some((step) => step.type === 'assert_ui_text' && step.label.includes('直播间')));
  assert.ok(plan.some((step) => step.type === 'assert_screen_changes'));
  assert.ok(plan.some((step) => step.type === 'swipe'));
});

test('Douyin live plan validates Live activity and screen motion', () => {
  const plan = buildLiveEntryPlan({
    app: { id: 'douyin', name: '抖音', packageName: 'com.ss.android.ugc.aweme' },
    durationMs: 30_000,
    screen,
  });

  assert.ok(plan.some((step) => step.type === 'swipe_if_ui_text_not_matches' && step.label.includes('顶部频道栏')));
  assert.ok(plan.some((step) => step.type === 'tap_text_region' && step.texts.includes('直播')));
  assert.ok(plan.some((step) => step.type === 'assert_ui_text_or_activity' && step.label.includes('直播频道')));
  assert.ok(plan.some((step) => step.type === 'tap_if_activity_not_matches' && step.label.includes('直播预览')));
  assert.ok(
    plan.some(
      (step) =>
        step.type === 'assert_foreground_package' &&
        step.activityAny?.some((matcher) => matcher instanceof RegExp && matcher.test('LivePlayActivity')),
    ),
  );
  assert.ok(
    plan.some((step) => step.type === 'assert_ui_text' && step.label.includes('直播间文本证据') && step.optional),
  );
  assert.ok(plan.some((step) => step.type === 'assert_screen_changes'));
});

test('meeting link plan opens a join URL and checks prompts', () => {
  const plan = buildMeetingLinkPlan({
    app: { name: '腾讯会议', packageName: 'com.tencent.wemeet.app' },
    meetingUrl: 'https://meeting.tencent.com/dm/abc',
    durationMs: 12_000,
  });

  assert.ok(plan.some((step) => step.type === 'open_uri' && step.uri.includes('meeting.tencent.com')));
  assert.ok(plan.some((step) => step.type === 'assert_no_sensitive_prompt'));
  assert.ok(plan.some((step) => step.type === 'tap_text' && step.texts.includes('加入会议')));
  assert.ok(plan.some((step) => step.type === 'complete'));
});

test('meeting link plan rejects unsafe URL schemes', () => {
  assert.throws(
    () =>
      buildMeetingLinkPlan({
        app: { name: '腾讯会议', packageName: 'com.tencent.wemeet.app' },
        meetingUrl: 'javascript:alert(1)',
      }),
    /valid meeting URL/,
  );
});

test('AI chat plan uses English messages and prompt guard', () => {
  const plan = buildAiChatPlan({
    app: { id: 'qianwen', name: '千问', packageName: 'com.aliyun.tongyi' },
    durationMs: 12_000,
    intervalMs: 10_000,
    screen,
  });

  assert.ok(plan.some((step) => step.type === 'assert_no_sensitive_prompt'));
  assert.ok(plan.some((step) => step.type === 'input_text'));
  assert.ok(plan.filter((step) => step.type === 'input_text').every((step) => /^[\x20-\x7E]+$/.test(step.text)));
});
