import { config } from '../config.js';

const DEFAULT_SCREEN = { width: config.screen.defaultWidth, height: config.screen.defaultHeight };
const DEFAULT_DURATION_MS = 10 * 60 * 1000;
const MAX_DURATION_MS = 2 * 60 * 60 * 1000;
const DEFAULT_INTERVAL_MS = 30 * 1000;
const MIN_INTERVAL_MS = 10 * 1000;
const MAX_INTERVAL_MS = 5 * 60 * 1000;

const DEFAULT_MESSAGES = [
  'Reply with one short English sentence about productivity.',
  'Ask one simple English question.',
  'Give one concise English learning tip.',
];

export function buildAiChatPlan({
  app,
  durationMs = DEFAULT_DURATION_MS,
  intervalMs = DEFAULT_INTERVAL_MS,
  messages = DEFAULT_MESSAGES,
  screen = DEFAULT_SCREEN,
}) {
  if (!app?.packageName) {
    throw new Error('AI chat skill requires an app packageName');
  }

  const safeDuration = Math.max(1000, Math.min(durationMs, MAX_DURATION_MS));
  const safeInterval = Math.max(MIN_INTERVAL_MS, Math.min(intervalMs, MAX_INTERVAL_MS));
  const size = {
    width: Number(screen.width) || DEFAULT_SCREEN.width,
    height: Number(screen.height) || DEFAULT_SCREEN.height,
  };
  const centerX = Math.round(size.width * 0.5);
  const inputY = Math.round(size.height * 0.92);
  const sendX = Math.round(size.width * 0.9);
  const usableMessages = Array.isArray(messages) && messages.length > 0 ? messages : DEFAULT_MESSAGES;

  const steps = [
    { type: 'launch_app', packageName: app.packageName, label: `打开${app.name}` },
    { type: 'wait', ms: Math.min(5000, safeDuration), label: '等待 AI 应用加载' },
    { type: 'assert_no_sensitive_prompt', label: '检查协议和权限弹窗' },
    {
      type: 'tap_text',
      texts: ['稍后', '取消', '暂不', '跳过', '我知道了'],
      optional: true,
      partial: true,
      label: '关闭非必要提示',
    },
  ];

  let elapsed = sumWaits(steps);
  let index = 0;
  while (elapsed < safeDuration) {
    const message = sanitizeMessage(usableMessages[index % usableMessages.length]);
    steps.push({ type: 'tap', x: centerX, y: inputY, label: '聚焦输入框' });
    steps.push({ type: 'input_text', text: message, label: '输入英文测试消息' });
    steps.push({ type: 'tap_text', texts: ['发送', 'Send'], optional: true, partial: true, label: '尝试点击发送按钮' });
    steps.push({ type: 'tap', x: sendX, y: inputY, label: '备用发送点击' });

    const waitMs = Math.min(safeInterval, safeDuration - elapsed);
    if (waitMs > 0) {
      steps.push({ type: 'wait', ms: waitMs, label: `等待回复 ${Math.round(waitMs / 1000)} 秒` });
      elapsed += waitMs;
    }
    index += 1;
  }

  steps.push({ type: 'complete', label: `${app.name}AI 对话会话完成` });
  return steps;
}

function sanitizeMessage(message) {
  const text = String(message || '').replace(/[^\x20-\x7E]/g, '').trim();
  return text || DEFAULT_MESSAGES[0];
}

function sumWaits(steps) {
  return steps.filter((step) => step.type === 'wait').reduce((sum, step) => sum + step.ms, 0);
}
