import { config } from '../config.js';

const DEFAULT_SCREEN = { width: config.screen.defaultWidth, height: config.screen.defaultHeight };
const DEFAULT_DURATION_MS = 10 * 60 * 1000;
const DEFAULT_SWITCH_INTERVAL_MS = 60 * 1000;
const MAX_DURATION_MS = 2 * 60 * 60 * 1000;
const MIN_SWITCH_INTERVAL_MS = 5 * 1000;

export function buildLiveStreamPlan({
  app,
  durationMs = DEFAULT_DURATION_MS,
  switchIntervalMs = DEFAULT_SWITCH_INTERVAL_MS,
  screen = DEFAULT_SCREEN,
}) {
  const safeDuration = Math.max(1000, Math.min(durationMs, MAX_DURATION_MS));
  const safeInterval = Math.max(MIN_SWITCH_INTERVAL_MS, Math.min(switchIntervalMs, safeDuration));
  const size = {
    width: Number(screen.width) || DEFAULT_SCREEN.width,
    height: Number(screen.height) || DEFAULT_SCREEN.height,
  };

  const x = Math.round(size.width * 0.5);
  const startY = Math.round(size.height * 0.79);
  const endY = Math.round(size.height * 0.2);
  const steps = [];
  let elapsed = 0;
  let index = 0;

  while (elapsed < safeDuration) {
    const waitMs = Math.min(safeInterval, safeDuration - elapsed);
    steps.push({ type: 'wait', ms: waitMs, label: `观看直播 ${Math.round(waitMs / 1000)} 秒` });
    elapsed += waitMs;

    if (elapsed < safeDuration) {
      steps.push({
        type: 'swipe',
        x1: x,
        y1: startY,
        x2: x,
        y2: endY,
        durationMs: 420,
        label: `切换到下一场直播 ${index + 1}`,
      });
    }

    index += 1;
  }

  steps.push({ type: 'complete', label: `${app?.name || '直播'}观看完成` });
  return steps;
}
