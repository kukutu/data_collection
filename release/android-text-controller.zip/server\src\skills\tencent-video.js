import { config } from '../config.js';

const DEFAULT_SCREEN = { width: config.screen.defaultWidth, height: config.screen.defaultHeight };
const DEFAULT_DURATION_MS = 10 * 60 * 1000;
const MAX_DURATION_MS = 2 * 60 * 60 * 1000;
const WAIT_CHUNK_MS = 60 * 1000;

export function buildTencentVideoPlaybackPlan({
  app,
  durationMs = DEFAULT_DURATION_MS,
  screen = DEFAULT_SCREEN,
}) {
  if (!app?.packageName) {
    throw new Error('Tencent Video skill requires an app packageName');
  }

  const safeDuration = Math.max(1000, Math.min(durationMs, MAX_DURATION_MS));
  const size = {
    width: Number(screen.width) || DEFAULT_SCREEN.width,
    height: Number(screen.height) || DEFAULT_SCREEN.height,
  };
  const centerX = Math.round(size.width * 0.5);

  const steps = [
    { type: 'keyevent', code: 'KEYCODE_BACK', label: '关闭可能残留的跳转弹窗' },
    { type: 'tap_resource', resourceId: 'android:id/button2', optional: true, label: '取消系统跳转确认' },
    { type: 'force_stop', packageName: app.packageName, label: '重置腾讯视频状态' },
    { type: 'launch_app', packageName: app.packageName, label: `打开${app.name}` },
    { type: 'wait', ms: Math.min(6000, safeDuration), label: '等待腾讯视频首页加载' },
    { type: 'assert_no_sensitive_prompt', label: '检查协议和权限弹窗' },
    {
      type: 'tap',
      x: centerX,
      y: Math.round(size.height * 0.35),
      label: '点击首页内容进入榜单或内容页',
    },
    { type: 'wait', ms: 2500, label: '等待内容列表加载' },
    {
      type: 'tap',
      x: Math.round(size.width * 0.16),
      y: Math.round(size.height * 0.2),
      label: '点击榜单第一条进入视频详情页',
    },
    { type: 'wait', ms: 4000, label: '等待播放页加载' },
    {
      type: 'tap',
      x: centerX,
      y: Math.round(size.height * 0.18),
      label: '点击播放器区域开始或恢复播放',
    },
    { type: 'wait', ms: 1000, label: '确认播放页稳定' },
    { type: 'assert_no_sensitive_prompt', label: '检查播放页权限弹窗' },
    {
      type: 'assert_foreground_package',
      packageName: app.packageName,
      label: '确认仍在腾讯视频播放页',
    },
    {
      type: 'assert_screen_changes',
      intervalMs: 1500,
      minDiffRatio: 0.0005,
      label: '确认腾讯视频画面在播放',
      message: '腾讯视频画面变化不足，疑似未进入真实播放页',
    },
  ];

  let elapsed = steps
    .filter((step) => step.type === 'wait')
    .reduce((sum, step) => sum + step.ms, 0);

  while (elapsed < safeDuration) {
    const waitMs = Math.min(WAIT_CHUNK_MS, safeDuration - elapsed);
    steps.push({ type: 'wait', ms: waitMs, label: `保持播放 ${Math.round(waitMs / 1000)} 秒` });
    elapsed += waitMs;
  }

  steps.push({ type: 'complete', label: '腾讯视频播放会话完成' });
  return steps;
}
