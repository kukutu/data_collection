const DEFAULT_DURATION_MS = 30 * 60 * 1000;
const MAX_DURATION_MS = 4 * 60 * 60 * 1000;
const WAIT_CHUNK_MS = 60 * 1000;

const JOIN_BUTTON_TEXTS = ['加入会议', '加入会议室', '进入会议', '立即加入', '入会'];

export function buildMeetingLinkPlan({ app, meetingUrl, durationMs = DEFAULT_DURATION_MS }) {
  if (!app?.packageName) {
    throw new Error('meeting link skill requires an app packageName');
  }

  const cleanUrl = String(meetingUrl || '').trim();
  if (!isAllowedMeetingUrl(cleanUrl)) {
    throw new Error('meeting link skill requires a valid meeting URL');
  }

  const safeDuration = Math.max(1000, Math.min(durationMs, MAX_DURATION_MS));
  const steps = [
    {
      type: 'open_uri',
      packageName: app.packageName,
      uri: cleanUrl,
      label: `打开${app.name}入会地址`,
    },
    { type: 'wait', ms: Math.min(10000, safeDuration), label: '等待会议链接打开' },
    { type: 'assert_no_sensitive_prompt', label: '检查协议和权限弹窗' },
    {
      type: 'tap_text',
      texts: JOIN_BUTTON_TEXTS,
      optional: true,
      label: '尝试点击入会按钮',
    },
    { type: 'wait', ms: Math.min(5000, safeDuration), label: '等待会议页面加载' },
    { type: 'assert_no_sensitive_prompt', label: '检查入会后的权限弹窗' },
  ];

  let elapsed = sumWaits(steps);
  while (elapsed < safeDuration) {
    const waitMs = Math.min(WAIT_CHUNK_MS, safeDuration - elapsed);
    steps.push({ type: 'wait', ms: waitMs, label: `保持会议 ${Math.round(waitMs / 1000)} 秒` });
    elapsed += waitMs;
  }

  steps.push({ type: 'complete', label: `${app.name}会议会话完成` });
  return steps;
}

export function isAllowedMeetingUrl(value) {
  try {
    const url = new URL(String(value || '').trim());
    return ['http:', 'https:', 'wemeet:', 'dingtalk:', 'feishu:', 'lark:', 'welink:', 'welinkapp:'].includes(
      url.protocol.toLowerCase(),
    );
  } catch {
    return false;
  }
}

function sumWaits(steps) {
  return steps.filter((step) => step.type === 'wait').reduce((sum, step) => sum + step.ms, 0);
}
