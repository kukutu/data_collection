const state = {
  currentTaskId: null,
  pollTimer: null,
  apps: [],
  activeBuilder: null,
};

const builders = {
  'short-video': {
    title: '短视频任务',
    verb: '刷',
    defaultDuration: 30,
    defaultUnit: '秒',
    appOptions: (apps) => [
      ...apps
        .filter((app) => app.installed && app.skill === 'short_video_feed')
        .map((app) => ({
          label: app.id === 'xiaohongshu' ? '小红书视频' : app.name,
          appName: app.id === 'xiaohongshu' ? '小红书视频' : app.name,
        })),
      ...apps
        .filter((app) => app.installed && app.id === 'wechat')
        .map(() => ({ label: '微信视频号', appName: '微信视频号' })),
    ],
    command: ({ duration, appName }) => `刷${duration}${appName}`,
    emptyMessage: '未检测到已安装且已实现的短视频 App。当前短视频已实现：抖音、小红书视频、快手、西瓜视频、微信视频号。',
  },
  'long-video': {
    title: '长视频任务',
    defaultDuration: 5,
    defaultUnit: '分钟',
    appOptions: (apps) =>
      apps
        .filter((app) => app.installed && ['tencent-video', 'bilibili', 'youku'].includes(app.id))
        .map((app) => ({ label: app.name, appName: app.name })),
    command: ({ duration, appName }) => `看${duration}${appName}`,
    emptyMessage: '未检测到已安装且已实现的长视频 App。当前长视频已实现：腾讯视频、B站、优酷。',
  },
  live: {
    title: '直播任务（试验）',
    defaultDuration: 5,
    defaultUnit: '分钟',
    appOptions: (apps) =>
      apps
        .filter((app) => app.installed && (app.categories || []).includes('直播'))
        .map((app) => ({
          label: app.id === 'wechat' ? '微信视频号直播' : app.name,
          appName: app.id === 'wechat' ? '微信视频号' : app.name,
        })),
    command: ({ duration, appName }) => `看${duration}${appName}直播`,
    warning: '直播任务目前是试验项：会尝试进入直播入口，但还未逐个 App 验收到真实直播播放页。',
    emptyMessage: '未检测到已安装且表中属于直播分类的 App。',
  },
  meeting: {
    title: '会议任务',
    defaultDuration: 30,
    defaultUnit: '分钟',
    needsUrl: true,
    appOptions: (apps) =>
      apps
        .filter((app) => app.installed && (app.categories || []).includes('会议'))
        .map((app) => ({ label: app.name, appName: app.name })),
    command: ({ duration, appName, url }) => `用${appName}加入会议 ${url} ${duration}`,
    emptyMessage: '未检测到已安装且表中属于会议分类的 App。当前会议需要填写入会地址。',
  },
  navigation: {
    title: '导航任务',
    defaultDuration: 5,
    defaultUnit: '分钟',
    needsDestination: true,
    defaultDestination: '北京站',
    appOptions: (apps) =>
      apps
        .filter((app) => app.installed && app.id === 'amap')
        .map((app) => ({ label: app.name, appName: app.name })),
    command: ({ duration, appName, destination }) => `${appName}导航到${destination}${duration}`,
    emptyMessage: '未检测到已安装且已实现的导航 App。当前导航已实现：高德地图。',
  },
  'ai-chat': {
    title: 'AI 应用任务',
    defaultDuration: 5,
    defaultUnit: '分钟',
    appOptions: (apps) =>
      apps
        .filter((app) => app.installed && ['doubao', 'qianwen'].includes(app.id))
        .map((app) => ({ label: app.name, appName: app.name })),
    command: ({ duration, appName }) => `和${appName}聊天${duration}`,
    emptyMessage: '未检测到已安装且已实现的 AI 应用。当前 AI 应用已实现：豆包、千问。',
  },
};

const elements = {
  taskForm: document.querySelector('#taskForm'),
  taskText: document.querySelector('#taskText'),
  apiKey: document.querySelector('#apiKey'),
  parseMode: document.querySelector('#parseMode'),
  stopBtn: document.querySelector('#stopBtn'),
  logs: document.querySelector('#logs'),
  taskState: document.querySelector('#taskState'),
  deviceLine: document.querySelector('#deviceLine'),
  statusPill: document.querySelector('#statusPill'),
  quickTaskDialog: document.querySelector('#quickTaskDialog'),
  dialogTitle: document.querySelector('#dialogTitle'),
  dialogCloseBtn: document.querySelector('#dialogCloseBtn'),
  builderApp: document.querySelector('#builderApp'),
  builderDuration: document.querySelector('#builderDuration'),
  builderUnit: document.querySelector('#builderUnit'),
  builderDestinationWrap: document.querySelector('#builderDestinationWrap'),
  builderDestination: document.querySelector('#builderDestination'),
  builderUrlWrap: document.querySelector('#builderUrlWrap'),
  builderUrl: document.querySelector('#builderUrl'),
  builderMessage: document.querySelector('#builderMessage'),
  fillTaskBtn: document.querySelector('#fillTaskBtn'),
  runBuiltTaskBtn: document.querySelector('#runBuiltTaskBtn'),
};

elements.taskForm.addEventListener('submit', async (event) => {
  event.preventDefault();
  await startTask(elements.taskText.value);
});

elements.stopBtn.addEventListener('click', async () => {
  if (!state.currentTaskId) return;
  await fetch(`/api/tasks/${state.currentTaskId}/stop`, { method: 'POST' });
  await pollTask();
});

document.querySelectorAll('[data-command]').forEach((button) => {
  button.addEventListener('click', () => {
    elements.taskText.value = button.dataset.command;
    elements.taskText.focus();
  });
});

document.querySelectorAll('[data-builder]').forEach((button) => {
  button.addEventListener('click', async () => {
    await openBuilder(button.dataset.builder);
  });
});

elements.dialogCloseBtn.addEventListener('click', () => {
  elements.quickTaskDialog.close();
});

elements.fillTaskBtn.addEventListener('click', () => {
  const command = buildCommandFromDialog();
  if (!command) return;
  elements.taskText.value = command;
  elements.quickTaskDialog.close();
  elements.taskText.focus();
});

elements.runBuiltTaskBtn.addEventListener('click', async () => {
  const command = buildCommandFromDialog();
  if (!command) return;
  elements.taskText.value = command;
  elements.quickTaskDialog.close();
  await startTask(command);
});

async function startTask(taskText) {
  const response = await fetch('/api/tasks', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      taskText,
      apiKey: elements.apiKey.value.trim(),
      parseMode: elements.parseMode.value,
      useModel: elements.parseMode.value === 'api',
    }),
  });
  const task = await response.json();
  state.currentTaskId = task.id;
  renderTask(task);
  startPolling();
}

async function openBuilder(builderId) {
  const builder = builders[builderId];
  if (!builder) return;

  state.activeBuilder = builderId;
  await refreshApps();

  const apps = builder.appOptions(state.apps);
  elements.dialogTitle.textContent = builder.title;
  elements.builderDuration.value = builder.defaultDuration;
  elements.builderUnit.value = builder.defaultUnit;
  elements.builderDestination.value = builder.defaultDestination || '';
  elements.builderUrl.value = builder.defaultUrl || '';
  elements.builderDestinationWrap.hidden = !builder.needsDestination;
  elements.builderUrlWrap.hidden = !builder.needsUrl;
  elements.builderApp.replaceChildren(
    ...apps.map((app) => {
      const option = document.createElement('option');
      option.value = app.appName;
      option.textContent = app.label;
      return option;
    }),
  );

  const hasApps = apps.length > 0;
  elements.builderApp.disabled = !hasApps;
  elements.builderDuration.disabled = !hasApps;
  elements.builderUnit.disabled = !hasApps;
  elements.builderDestination.disabled = !hasApps;
  elements.builderUrl.disabled = !hasApps;
  elements.fillTaskBtn.disabled = !hasApps;
  elements.runBuiltTaskBtn.disabled = !hasApps;
  elements.builderMessage.textContent = hasApps ? '' : builder.emptyMessage;
  if (hasApps && builder.warning) elements.builderMessage.textContent = builder.warning;

  elements.quickTaskDialog.showModal();
}

function buildCommandFromDialog() {
  const builder = builders[state.activeBuilder];
  if (!builder || !elements.builderApp.value) return '';

  const amount = Number(elements.builderDuration.value);
  if (!Number.isFinite(amount) || amount <= 0) {
    elements.builderMessage.textContent = '时长必须大于 0。';
    elements.builderDuration.focus();
    return '';
  }

  const duration = `${Math.round(amount)}${elements.builderUnit.value}`;
  const destination = elements.builderDestination.value.trim();
  const url = elements.builderUrl.value.trim();
  if (builder.needsDestination && !destination) {
    elements.builderMessage.textContent = '目的地不能为空。';
    elements.builderDestination.focus();
    return '';
  }
  if (builder.needsUrl && !url) {
    elements.builderMessage.textContent = '入会地址不能为空。';
    elements.builderUrl.focus();
    return '';
  }
  if (builder.needsUrl && !isUrlLike(url)) {
    elements.builderMessage.textContent = '入会地址必须是完整链接。';
    elements.builderUrl.focus();
    return '';
  }

  return builder.command({
    duration,
    appName: elements.builderApp.value,
    destination,
    url,
  });
}

function isUrlLike(value) {
  return /^[a-z][a-z0-9+.-]*:\/\/\S+$/i.test(value);
}

function startPolling() {
  clearInterval(state.pollTimer);
  state.pollTimer = setInterval(pollTask, 1000);
  pollTask();
}

async function pollTask() {
  if (!state.currentTaskId) return;
  const response = await fetch(`/api/tasks/${state.currentTaskId}`);
  const task = await response.json();
  renderTask(task);

  if (['completed', 'failed', 'blocked', 'stopped'].includes(task.status)) {
    clearInterval(state.pollTimer);
    await refreshDevice();
  }
}

function renderTask(task) {
  elements.taskState.textContent = `${task.status || 'unknown'} ${task.stepIndex || 0}/${task.totalSteps || 0}`;
  elements.logs.textContent = (task.logs || [])
    .map((entry) => `${new Date(entry.at).toLocaleTimeString()}  ${entry.message}`)
    .join('\n');
  elements.logs.scrollTop = elements.logs.scrollHeight;
}

async function refreshDevice() {
  const response = await fetch('/api/device');
  const device = await response.json();

  elements.statusPill.classList.toggle('connected', Boolean(device.connected));
  elements.statusPill.textContent = device.connected ? '已连接' : '未连接';
  elements.deviceLine.textContent = device.connected
    ? `${device.model || 'Android'} · ${device.serial} · ${device.focus?.packageName || '无前台应用'}`
    : '未检测到 ADB 设备';
}

async function refreshApps() {
  const response = await fetch('/api/apps');
  state.apps = await response.json();
}

await Promise.all([refreshDevice(), refreshApps()]);
setInterval(refreshDevice, 5000);
