import test from 'node:test';
import assert from 'node:assert/strict';

import { loadApps } from '../server/src/app-registry.js';
import { parseTaskFallback } from '../server/src/task-parser.js';

const apps = loadApps();

test('parses Tencent Video watch tasks as playback sessions', () => {
  const parsed = parseTaskFallback('看10分钟腾讯视频', apps);

  assert.equal(parsed.intent, 'play_tencent_video');
  assert.equal(parsed.appName, '腾讯视频');
  assert.equal(parsed.durationMs, 10 * 60 * 1000);
  assert.equal(parsed.openFirstAvailable, true);
});

test('parses non-implemented long-video watch tasks as unsupported flows', () => {
  const parsed = parseTaskFallback('看10分钟爱奇艺', apps);

  assert.equal(parsed.intent, 'unsupported_flow');
  assert.equal(parsed.appName, '爱奇艺');
});

test('parses meeting tasks only when a join URL is provided', () => {
  const meeting = parseTaskFallback('保持5分钟腾讯会议', apps);
  const meetingWithUrl = parseTaskFallback('用腾讯会议加入会议 https://meeting.tencent.com/dm/abc 5分钟', apps);
  const voip = parseTaskFallback('测试1分钟微信音视频通话', apps);

  assert.equal(meeting.intent, 'missing_parameter');
  assert.equal(meeting.appName, '腾讯会议');
  assert.equal(meeting.field, 'meetingUrl');
  assert.equal(meetingWithUrl.intent, 'meeting_link');
  assert.equal(meetingWithUrl.appName, '腾讯会议');
  assert.equal(meetingWithUrl.meetingUrl, 'https://meeting.tencent.com/dm/abc');
  assert.equal(meetingWithUrl.durationMs, 5 * 60 * 1000);
  assert.equal(voip.intent, 'unsupported_flow');
  assert.equal(voip.appName, '微信');
});

test('parses upload/download tasks as unsupported flows', () => {
  const download = parseTaskFallback('测试2分钟百度网盘下载', apps);

  assert.equal(download.intent, 'unsupported_flow');
  assert.equal(download.appName, '百度网盘');
});

test('requires destination for AMap navigation and parses destination when present', () => {
  const missingDestination = parseTaskFallback('运行3分钟高德地图导航', apps);
  const navigation = parseTaskFallback('运行4秒高德地图导航到北京站', apps);

  assert.equal(missingDestination.intent, 'missing_parameter');
  assert.equal(missingDestination.field, 'destination');
  assert.equal(navigation.intent, 'amap_navigation');
  assert.equal(navigation.appName, '高德地图');
  assert.equal(navigation.destination, '北京站');
  assert.equal(navigation.durationMs, 4000);
});

test('parses installed actual app-specific sessions', () => {
  const qq = parseTaskFallback('测试1分钟QQ音视频通话', apps);
  const ai = parseTaskFallback('和千问聊天5分钟', apps);

  assert.equal(qq.intent, 'unsupported_flow');
  assert.equal(ai.intent, 'ai_chat');
});
