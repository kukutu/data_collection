import { config } from '../config.js';

const DEFAULT_SCREEN = { width: config.screen.defaultWidth, height: config.screen.defaultHeight };
const DEFAULT_DURATION_MS = 5 * 60 * 1000;
const MAX_DURATION_MS = 2 * 60 * 60 * 1000;

export function buildShortVideoPlan({ app, durationMs = DEFAULT_DURATION_MS, screen = DEFAULT_SCREEN }) {
  if (!app?.packageName) {
    throw new Error('short-video skill requires an app packageName');
  }

  const safeDuration = Math.max(1000, Math.min(durationMs, MAX_DURATION_MS));
  const size = {
    width: Number(screen.width) || DEFAULT_SCREEN.width,
    height: Number(screen.height) || DEFAULT_SCREEN.height,
  };

  const x = Math.round(size.width * 0.5);
  const startY = Math.round(size.height * 0.79);
  const endY = Math.round(size.height * 0.2);
  const steps = buildEntrySteps({ app, x, startY, endY });

  let elapsed = sumWaits(steps);
  let index = 0;

  while (elapsed < safeDuration) {
    const waitMs = Math.min(5000 + (index % 5) * 2000, safeDuration - elapsed);
    if (waitMs > 0) {
      steps.push({ type: 'wait', ms: waitMs, label: `观看 ${Math.round(waitMs / 1000)} 秒` });
      elapsed += waitMs;
    }

    if (elapsed < safeDuration) {
      steps.push({
        type: 'swipe',
        x1: x,
        y1: startY,
        x2: x,
        y2: endY,
        durationMs: 320 + (index % 4) * 90,
        label: '上滑下一条',
      });
      elapsed += 800;
    }

    index += 1;
  }

  steps.push({ type: 'complete', label: `${app.name}浏览完成` });
  return steps;
}

function buildEntrySteps({ app, x, startY, endY }) {
  const steps = [];

  if (app.id === 'xiaohongshu') {
    steps.push({ type: 'force_stop', packageName: app.packageName, label: '重置小红书状态' });
  }

  steps.push(
    { type: 'launch_app', packageName: app.packageName, label: `打开${app.name}` },
    { type: 'wait', ms: 3000, label: '等待应用加载' },
    { type: 'assert_no_sensitive_prompt', label: '检查协议和权限弹窗' },
  );

  if (app.id === 'xiaohongshu') {
    steps.push(
      { type: 'tap_text', texts: ['视频'], partial: true, label: '进入小红书视频内容' },
      { type: 'wait', ms: 3000, label: '等待小红书视频流加载' },
      { type: 'assert_no_sensitive_prompt', label: '检查视频流弹窗' },
      {
        type: 'assert_ui_text',
        any: [/已播放到/, '暂停'],
        label: '确认小红书进入视频播放页',
        message: '小红书未进入可验证的视频播放页',
      },
    );
  }

  if (app.id === 'douyin') {
    steps.push({
      type: 'swipe_while_ui_text_matches',
      matches: [/图片\d/, /图文/],
      maxSwipes: 5,
      x1: x,
      y1: startY,
      x2: x,
      y2: endY,
      durationMs: 360,
      afterSwipeWaitMs: 1200,
      label: '跳过抖音图文内容',
      swipeLabel: '检测到抖音图文内容，跳过',
      message: '连续跳过后仍停留在抖音图文内容，未进入短视频播放页',
    });
  }

  steps.push(
    {
      type: 'assert_foreground_package',
      packageName: app.packageName,
      label: `确认仍在${app.name}`,
    },
    {
      type: 'assert_screen_changes',
      intervalMs: 1200,
      minDiffRatio: 0.0005,
      label: '确认短视频画面在播放',
      message: `${app.name}画面变化不足，疑似没有进入视频播放内容`,
    },
  );

  return steps;
}

function sumWaits(steps) {
  return steps.filter((step) => step.type === 'wait').reduce((sum, step) => sum + step.ms, 0);
}
