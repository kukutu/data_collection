import { randomUUID } from 'node:crypto';

import { findAppByName } from './app-registry.js';
import { parseTaskWithCodexCli, parseTaskWithModel } from './llm.js';
import { parseTaskFallback } from './task-parser.js';
import { evaluateSafety } from './safety.js';
import { buildAiChatPlan } from './skills/ai-chat.js';
import { buildDoubaoChatPlan } from './skills/doubao-chat.js';
import { buildLiveStreamPlan } from './skills/live-stream.js';
import { buildShortVideoPlan } from './skills/short-video.js';
import { buildAmapNavigationPlan } from './skills/amap-navigation.js';
import { buildGenericMediaPlaybackPlan } from './skills/generic-media.js';
import { buildLiveEntryPlan } from './skills/live-entry.js';
import { buildMeetingLinkPlan } from './skills/meeting-link.js';
import { buildTencentVideoPlaybackPlan } from './skills/tencent-video.js';
import { buildWechatChannelsPlan } from './skills/wechat-channels.js';

export class TaskManager {
  constructor({ adb, apps }) {
    this.adb = adb;
    this.apps = apps;
    this.tasks = new Map();
  }

  start({ taskText, apiKey, useModel = false, parseMode }) {
    const task = {
      id: randomUUID(),
      input: taskText,
      status: 'running',
      stepIndex: 0,
      totalSteps: 0,
      logs: [],
      startedAt: new Date().toISOString(),
      stopped: false,
    };

    this.tasks.set(task.id, task);
    this.#run(task, { apiKey, useModel, parseMode }).catch((error) => {
      if (task.status === 'stopped') return;
      task.status = 'failed';
      task.error = error.message;
      this.#log(task, `失败: ${error.message}`);
    });

    return this.snapshot(task.id);
  }

  snapshot(taskId) {
    const task = this.tasks.get(taskId);
    if (!task) return null;
    return {
      id: task.id,
      input: task.input,
      status: task.status,
      parsed: task.parsed,
      stepIndex: task.stepIndex,
      totalSteps: task.totalSteps,
      logs: task.logs.slice(-200),
      error: task.error,
      startedAt: task.startedAt,
      finishedAt: task.finishedAt,
    };
  }

  stop(taskId) {
    const task = this.tasks.get(taskId);
    if (!task) return false;
    task.stopped = true;
    this.#log(task, '收到停止请求');
    return true;
  }

  async #run(task, { apiKey, useModel, parseMode }) {
    this.#log(task, '开始解析任务');
    task.parsed = await this.#parse(task.input, { apiKey, useModel, parseMode });
    this.#log(task, `解析结果: ${JSON.stringify(task.parsed)}`);

    const safety = evaluateSafety(task.parsed, task.input);
    if (!safety.allowed) {
      task.status = 'blocked';
      task.error = safety.reason;
      task.finishedAt = new Date().toISOString();
      this.#log(task, safety.reason);
      return;
    }

    await this.#execute(task);

    if (task.status !== 'stopped') {
      task.status = 'completed';
      task.finishedAt = new Date().toISOString();
      this.#log(task, '任务完成');
    }
  }

  async #parse(taskText, { apiKey, useModel, parseMode }) {
    const mode = parseMode || (useModel ? 'api' : 'rules');

    if (mode === 'api' && apiKey) {
      try {
        return await parseTaskWithModel({ taskText, apiKey, apps: this.apps });
      } catch (error) {
        return {
          ...parseTaskFallback(taskText, this.apps),
          modelError: error.message,
        };
      }
    }

    if (mode === 'api' && !apiKey) {
      return {
        ...parseTaskFallback(taskText, this.apps),
        modelError: 'API 模式需要在前端填写 API Key',
      };
    }

    if (mode === 'codex') {
      try {
        return await parseTaskWithCodexCli({ taskText, apps: this.apps });
      } catch (error) {
        return {
          ...parseTaskFallback(taskText, this.apps),
          codexError: error.message,
        };
      }
    }

    return parseTaskFallback(taskText, this.apps);
  }

  async #execute(task) {
    switch (task.parsed.intent) {
      case 'launch_app':
        return this.#launch(task);
      case 'watch_feed':
        return this.#watchFeed(task);
      case 'watch_live':
        return this.#watchLive(task);
      case 'live_entry':
        return this.#liveEntry(task);
      case 'play_tencent_video':
        return this.#playTencentVideo(task);
      case 'play_generic_media':
        return this.#playGenericMedia(task);
      case 'amap_navigation':
        return this.#amapNavigation(task);
      case 'meeting_link':
        return this.#meetingLink(task);
      case 'wechat_channels_feed':
        return this.#wechatChannels(task);
      case 'ai_chat':
        return this.#aiChat(task);
      case 'doubao_chat':
        return this.#doubaoChat(task);
      case 'back':
        return this.#key(task, 'KEYCODE_BACK', '返回');
      case 'home':
        return this.#key(task, 'KEYCODE_HOME', '回到桌面');
      default:
        throw new Error(`unsupported intent: ${task.parsed.intent}`);
    }
  }

  async #launch(task) {
    const app = this.#resolveApp(task.parsed.appName);
    this.#log(task, `打开 ${app.name}`);
    await this.adb.launchPackage(app.packageName);
  }

  async #watchFeed(task) {
    const app = this.#resolveApp(task.parsed.appName);
    if (app.skill !== 'short_video_feed') {
      throw new Error(`${app.name} 暂未实现可自动浏览的 skill`);
    }

    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildShortVideoPlan({
      app,
      durationMs: task.parsed.durationMs,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #watchLive(task) {
    const app = this.#resolveApp(task.parsed.appName);
    const focus = await this.adb.getCurrentFocus?.().catch(() => null);
    if (focus?.packageName && focus.packageName !== app.packageName) {
      throw new Error(`请先手动进入${app.name}直播间，再启动直播切换任务`);
    }

    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildLiveStreamPlan({
      app,
      durationMs: task.parsed.durationMs,
      switchIntervalMs: task.parsed.switchIntervalMs,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #doubaoChat(task) {
    const app = this.#resolveApp(task.parsed.appName || '豆包');
    if (app.skill !== 'doubao_chat') {
      throw new Error('doubao_chat 只能用于豆包 App');
    }

    const steps = buildDoubaoChatPlan({
      app,
      durationMs: task.parsed.durationMs,
      intervalMs: task.parsed.intervalMs,
      messages: task.parsed.messages,
    });

    await this.#runSteps(task, steps);
  }

  async #playTencentVideo(task) {
    const app = this.#resolveApp(task.parsed.appName);
    if (app.id !== 'tencent-video') {
      throw new Error('play_tencent_video 只能用于腾讯视频 App');
    }
    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildTencentVideoPlaybackPlan({
      app,
      durationMs: task.parsed.durationMs,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #amapNavigation(task) {
    const app = this.#resolveApp(task.parsed.appName);
    if (app.id !== 'amap') {
      throw new Error('amap_navigation 只能用于高德地图 App');
    }
    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildAmapNavigationPlan({
      app,
      destination: task.parsed.destination,
      durationMs: task.parsed.durationMs,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #playGenericMedia(task) {
    const app = this.#resolveApp(task.parsed.appName);
    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildGenericMediaPlaybackPlan({
      app,
      durationMs: task.parsed.durationMs,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #meetingLink(task) {
    const app = this.#resolveApp(task.parsed.appName);
    if (!(app.categories || []).includes('会议')) {
      throw new Error('meeting_link 只能用于会议分类 App');
    }

    const steps = buildMeetingLinkPlan({
      app,
      meetingUrl: task.parsed.meetingUrl,
      durationMs: task.parsed.durationMs,
    });

    await this.#runSteps(task, steps);
  }

  async #wechatChannels(task) {
    const app = this.#resolveApp(task.parsed.appName);
    if (app.id !== 'wechat') {
      throw new Error('wechat_channels_feed 只能用于微信 App');
    }
    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildWechatChannelsPlan({
      app,
      durationMs: task.parsed.durationMs,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #liveEntry(task) {
    const app = this.#resolveApp(task.parsed.appName);
    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildLiveEntryPlan({
      app,
      durationMs: task.parsed.durationMs,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #aiChat(task) {
    const app = this.#resolveApp(task.parsed.appName);
    const screen = await this.adb.getScreenSize().catch(() => null);
    const steps = buildAiChatPlan({
      app,
      durationMs: task.parsed.durationMs,
      intervalMs: task.parsed.intervalMs,
      messages: task.parsed.messages,
      screen: screen || undefined,
    });

    await this.#runSteps(task, steps);
  }

  async #runSteps(task, steps) {
    task.totalSteps = steps.length;

    for (const [index, step] of steps.entries()) {
      this.#assertNotStopped(task);
      task.stepIndex = index + 1;
      this.#log(task, step.label || step.type);
      await this.#executeStep(step, task);
    }
  }

  async #key(task, code, label) {
    this.#log(task, label);
    await this.adb.keyevent(code);
  }

  async #executeStep(step, task) {
    switch (step.type) {
      case 'launch_app':
        await this.adb.launchPackage(step.packageName);
        return;
      case 'force_stop':
        await this.adb.forceStopPackage(step.packageName);
        return;
      case 'keyevent':
        await this.adb.keyevent(step.code);
        return;
      case 'wait':
        await this.#sleep(step.ms, task);
        return;
      case 'open_uri':
        await this.adb.openUri(step);
        return;
      case 'tap':
        await this.adb.tap(step);
        return;
      case 'swipe':
        await this.adb.swipe(step);
        return;
      case 'tap_resource':
        await this.adb.tapResource(step.resourceId, { optional: Boolean(step.optional) });
        return;
      case 'tap_text':
        await this.adb.tapText(step.texts || step.text, {
          optional: Boolean(step.optional),
          partial: Boolean(step.partial),
        });
        return;
      case 'tap_text_region':
        await this.adb.tapTextInRegion(step.texts || step.text, {
          optional: Boolean(step.optional),
          partial: Boolean(step.partial),
          region: step.region,
        });
        return;
      case 'assert_no_sensitive_prompt':
        await this.adb.assertNoSensitivePrompt();
        return;
      case 'assert_foreground_package':
        await this.#assertForegroundPackage(step);
        return;
      case 'assert_ui_text':
        await this.#assertUiText(step);
        return;
      case 'assert_ui_text_or_activity':
        await this.#assertUiTextOrActivity(step);
        return;
      case 'swipe_while_ui_text_matches':
        await this.#swipeWhileUiTextMatches(step, task);
        return;
      case 'swipe_if_ui_text_not_matches':
        await this.#swipeIfUiTextNotMatches(step);
        return;
      case 'tap_if_activity_not_matches':
        await this.#tapIfActivityNotMatches(step);
        return;
      case 'swipe_if_activity_not_matches':
        await this.#swipeIfActivityNotMatches(step);
        return;
      case 'assert_screen_changes':
        await this.#assertScreenChanges(step, task);
        return;
      case 'input_text':
        await this.adb.inputText(step.text);
        return;
      case 'complete':
        return;
      default:
        throw new Error(`unknown step type: ${step.type}`);
    }
  }

  #resolveApp(appName) {
    const app = findAppByName(this.apps, appName);
    if (!app) throw new Error(`未找到应用: ${appName}`);
    if (!app.packageName) throw new Error(`${app.name} 缺少 packageName`);
    return app;
  }

  async #assertForegroundPackage(step) {
    const expected = step.packageName;
    const focus = await this.adb.getCurrentFocus?.().catch(() => null);
    if (expected && focus?.packageName !== expected) {
      throw new Error(`当前前台应用为 ${focus?.packageName || 'unknown'}，不是预期的 ${expected}`);
    }

    if (step.activityAny && !this.#matchesAny(focus?.activity || '', step.activityAny)) {
      throw new Error(step.message || `当前 Activity ${focus?.activity || 'unknown'} 不符合预期`);
    }
  }

  async #assertUiText(step) {
    let snapshot = null;
    try {
      snapshot = await this.adb.getUiTextSnapshot();
    } catch (error) {
      if (step.optional) return;
      throw error;
    }
    const text = snapshot.text || '';

    if (step.any && !this.#matchesAny(text, step.any)) {
      if (step.optional) return;
      throw new Error(step.message || `屏幕未出现预期内容: ${this.#describeMatchers(step.any)}`);
    }

    if (step.all && !this.#matchesAll(text, step.all)) {
      if (step.optional) return;
      throw new Error(step.message || `屏幕缺少预期内容: ${this.#describeMatchers(step.all)}`);
    }

    if (step.none && this.#matchesAny(text, step.none)) {
      if (step.optional) return;
      throw new Error(step.message || `屏幕出现了不应出现的内容: ${this.#describeMatchers(step.none)}`);
    }
  }

  async #assertUiTextOrActivity(step) {
    const focus = await this.adb.getCurrentFocus?.().catch(() => null);
    if (step.packageName && focus?.packageName !== step.packageName) {
      throw new Error(`当前前台应用为 ${focus?.packageName || 'unknown'}，不是预期的 ${step.packageName}`);
    }
    if (this.#matchesAny(focus?.activity || '', step.activityAny || [])) return;
    await this.#assertUiText(step);
  }

  async #swipeWhileUiTextMatches(step, task) {
    const maxSwipes = Number.isFinite(Number(step.maxSwipes)) ? Number(step.maxSwipes) : 3;
    for (let attempt = 0; attempt <= maxSwipes; attempt += 1) {
      const snapshot = await this.adb.getUiTextSnapshot();
      if (!this.#matchesAny(snapshot.text || '', step.matches || [])) return;

      if (attempt >= maxSwipes) {
        if (step.required === false) return;
        throw new Error(step.message || `连续 ${maxSwipes} 次跳过后仍未进入目标内容`);
      }

      this.#log(task, `${step.swipeLabel || '检测到非目标内容，跳过'} ${attempt + 1}/${maxSwipes}`);
      await this.adb.swipe(step);
      await this.#sleep(step.afterSwipeWaitMs || 1000, task);
    }
  }

  async #swipeIfUiTextNotMatches(step) {
    const focus = await this.adb.getCurrentFocus?.().catch(() => null);
    if (this.#matchesAny(focus?.activity || '', step.activityAny || [])) return;

    const snapshot = await this.adb.getUiTextSnapshot();
    if (this.#matchesAny(snapshot.text || '', step.matches || step.any || [])) return;

    await this.adb.swipe(step);
  }

  async #tapIfActivityNotMatches(step) {
    const focus = await this.adb.getCurrentFocus?.().catch(() => null);
    if (this.#matchesAny(focus?.activity || '', step.activityAny || [])) return;
    await this.adb.tap(step);
  }

  async #swipeIfActivityNotMatches(step) {
    const focus = await this.adb.getCurrentFocus?.().catch(() => null);
    if (this.#matchesAny(focus?.activity || '', step.activityAny || [])) return;
    await this.adb.swipe(step);
  }

  async #assertScreenChanges(step, task) {
    if (!this.adb.screenshotPng) {
      if (step.optional) return;
      throw new Error('当前 ADB 实现不支持截图检测');
    }

    const first = await this.adb.screenshotPng();
    await this.#sleep(step.intervalMs || 1500, task);
    const second = await this.adb.screenshotPng();
    const ratio = estimateBufferDifference(first, second);
    const minimum = Number.isFinite(Number(step.minDiffRatio)) ? Number(step.minDiffRatio) : 0.001;

    if (ratio < minimum) {
      throw new Error(step.message || `屏幕变化不足，疑似未播放或未进入动态内容，变化率 ${ratio.toFixed(5)}`);
    }
  }

  #matchesAny(text, matchers = []) {
    return normalizeMatchers(matchers).some((matcher) => matcherMatches(text, matcher));
  }

  #matchesAll(text, matchers = []) {
    return normalizeMatchers(matchers).every((matcher) => matcherMatches(text, matcher));
  }

  #describeMatchers(matchers = []) {
    return normalizeMatchers(matchers).map((matcher) => matcher.toString()).join('/');
  }

  async #sleep(ms, task) {
    const end = Date.now() + ms;
    while (Date.now() < end) {
      this.#assertNotStopped(task);
      await new Promise((resolve) => setTimeout(resolve, Math.min(500, end - Date.now())));
    }
  }

  #assertNotStopped(task) {
    if (task.stopped) {
      task.status = 'stopped';
      task.finishedAt = new Date().toISOString();
      throw new TaskStoppedError();
    }
  }

  #log(task, message) {
    task.logs.push({
      at: new Date().toISOString(),
      message,
    });
  }
}

class TaskStoppedError extends Error {
  constructor() {
    super('task stopped');
  }
}

function normalizeMatchers(matchers) {
  if (!matchers) return [];
  return Array.isArray(matchers) ? matchers : [matchers];
}

function matcherMatches(text, matcher) {
  if (matcher instanceof RegExp) return matcher.test(text);
  return text.includes(String(matcher));
}

function estimateBufferDifference(first, second) {
  const a = Buffer.from(first || []);
  const b = Buffer.from(second || []);
  const length = Math.min(a.length, b.length);
  if (!length) return 0;

  const sampleCount = Math.min(200000, length);
  const stride = Math.max(1, Math.floor(length / sampleCount));
  let checked = 0;
  let different = Math.abs(a.length - b.length) > Math.max(128, length * 0.001) ? 1 : 0;

  for (let index = 0; index < length; index += stride) {
    checked += 1;
    if (a[index] !== b[index]) different += 1;
  }

  return checked > 0 ? different / checked : 0;
}
