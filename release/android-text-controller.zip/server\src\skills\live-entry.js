import { config } from '../config.js';

const DEFAULT_SCREEN = { width: config.screen.defaultWidth, height: config.screen.defaultHeight };
const DEFAULT_DURATION_MS = 5 * 60 * 1000;
const MAX_DURATION_MS = 2 * 60 * 60 * 1000;
const LIVE_EVIDENCE = [
  /直播间/,
  /正在直播/,
  /主播/,
  /连麦/,
  /送礼/,
  /礼物/,
  /粉丝团/,
  /小时榜/,
  /本场/,
  /讲解/,
  /购物袋/,
  /小黄车/,
  /热卖/,
  /开播/,
  /人气/,
  /观众/,
  /进来了/,
];
const DOUYIN_LIVE_ROOM_EVIDENCE = [
  /欢迎来到直播间/,
  /在线观众/,
  /说点什么/,
  /本场点赞/,
  /商品列表/,
  /连线/,
  /礼物/,
];

export function buildLiveEntryPlan({ app, durationMs = DEFAULT_DURATION_MS, screen = DEFAULT_SCREEN }) {
  if (!app?.packageName) {
    throw new Error('live entry skill requires an app packageName');
  }

  const safeDuration = Math.max(1000, Math.min(durationMs, MAX_DURATION_MS));
  const size = {
    width: Number(screen.width) || DEFAULT_SCREEN.width,
    height: Number(screen.height) || DEFAULT_SCREEN.height,
  };
  const x = Math.round(size.width * 0.5);
  const steps = [
    ...buildLiveEntrySteps({ app, size, x, safeDuration }),
    ...buildLiveValidationSteps(app),
  ];

  let elapsed = sumWaits(steps);
  let index = 0;
  while (elapsed < safeDuration) {
    const waitMs = Math.min(8000 + (index % 3) * 3000, safeDuration - elapsed);
    if (waitMs > 0) {
      steps.push({ type: 'wait', ms: waitMs, label: `观看直播 ${Math.round(waitMs / 1000)} 秒` });
      elapsed += waitMs;
    }
    if (elapsed < safeDuration) {
      steps.push({
        type: 'swipe',
        x1: x,
        y1: Math.round(size.height * 0.78),
        x2: x,
        y2: Math.round(size.height * 0.22),
        durationMs: 420,
        label: '切换下一场直播',
      });
      elapsed += 800;
    }
    index += 1;
  }

  steps.push({ type: 'complete', label: `${app.name}直播浏览完成` });
  return steps;
}

function buildLiveEntrySteps({ app, size, x, safeDuration }) {
  if (app.id === 'douyin') {
    return buildDouyinLiveEntrySteps({ app, size, safeDuration });
  }

  return [
    { type: 'launch_app', packageName: app.packageName, label: `打开${app.name}` },
    { type: 'wait', ms: Math.min(5000, safeDuration), label: '等待首页加载' },
    { type: 'assert_no_sensitive_prompt', label: '检查协议和权限弹窗' },
    {
      type: 'tap_text',
      texts: ['稍后', '取消', '暂不', '跳过', '我知道了'],
      optional: true,
      partial: true,
      label: '关闭非必要提示',
    },
    { type: 'tap_text', texts: ['直播'], optional: true, partial: true, label: '进入直播入口' },
    { type: 'wait', ms: 4000, label: '等待直播内容加载' },
    {
      type: 'tap_text',
      texts: ['点击进入直播间', '进入直播间', '直播中'],
      optional: true,
      partial: true,
      label: '点击直播间入口',
    },
    { type: 'wait', ms: 1500, label: '等待直播间入口响应' },
    {
      type: 'tap',
      x,
      y: Math.round(size.height * 0.38),
      label: '尝试进入直播内容',
    },
    { type: 'wait', ms: 3000, label: '等待直播间稳定' },
    { type: 'assert_no_sensitive_prompt', label: '检查直播页弹窗' },
  ];
}

function sumWaits(steps) {
  return steps.filter((step) => step.type === 'wait').reduce((sum, step) => sum + step.ms, 0);
}

function buildDouyinLiveEntrySteps({ app, size, safeDuration }) {
  const topY = Math.round(size.height * 0.08);
  const previewX = Math.round(size.width * 0.5);
  const previewY = Math.round(size.height * 0.69);
  const topRegion = {
    minX: 0,
    maxX: size.width,
    minY: 0,
    maxY: Math.round(size.height * 0.18),
  };
  const liveActivity = [/Live/i];

  return [
    { type: 'launch_app', packageName: app.packageName, label: '打开抖音' },
    { type: 'wait', ms: Math.min(5000, safeDuration), label: '等待抖音首页加载' },
    { type: 'keyevent', code: 'KEYCODE_MEDIA_PAUSE', label: '暂停当前视频以稳定顶部频道识别' },
    { type: 'wait', ms: 800, label: '等待当前视频暂停' },
    { type: 'assert_no_sensitive_prompt', label: '检查协议和权限弹窗' },
    {
      type: 'tap_text_region',
      texts: ['直播'],
      optional: true,
      region: topRegion,
      label: '点击顶部直播频道文本',
    },
    { type: 'wait', ms: 1000, label: '等待直播频道选中' },
    {
      type: 'swipe_if_ui_text_not_matches',
      activityAny: liveActivity,
      matches: [/已选中，直播/],
      x1: Math.round(size.width * 0.78),
      y1: topY,
      x2: Math.round(size.width * 0.22),
      y2: topY,
      durationMs: 280,
      label: '横滑顶部频道栏查找直播',
    },
    { type: 'wait', ms: 600, label: '等待顶部频道栏移动' },
    {
      type: 'tap_text_region',
      texts: ['直播'],
      optional: true,
      region: topRegion,
      label: '再次点击顶部直播频道文本',
    },
    { type: 'wait', ms: 1000, label: '等待直播频道再次选中' },
    {
      type: 'assert_ui_text_or_activity',
      packageName: app.packageName,
      activityAny: liveActivity,
      any: [/已选中，直播/],
      label: '确认已选中抖音直播频道',
      message: '抖音未选中顶部直播频道，停止以避免误点普通内容',
    },
    { type: 'wait', ms: 9000, label: '等待抖音直播频道加载' },
    {
      type: 'tap_if_activity_not_matches',
      activityAny: liveActivity,
      x: previewX,
      y: previewY,
      label: '点击直播预览画面',
    },
    { type: 'wait', ms: 8000, label: '等待抖音直播间加载' },
    {
      type: 'tap_if_activity_not_matches',
      activityAny: liveActivity,
      x: previewX,
      y: previewY,
      label: '再次点击直播预览画面',
    },
    { type: 'wait', ms: 6000, label: '等待直播间稳定' },
  ];
}

function buildLiveValidationSteps(app) {
  if (app.id === 'douyin') {
    return [
      {
        type: 'assert_foreground_package',
        packageName: app.packageName,
        activityAny: [/Live/i],
        label: '确认进入抖音直播 Activity',
        message: '抖音未进入直播 Activity，不能判定为真实直播播放',
      },
      {
        type: 'assert_ui_text',
        any: DOUYIN_LIVE_ROOM_EVIDENCE,
        optional: true,
        label: '辅助确认抖音直播间文本证据',
        message: '抖音未出现直播间控件或直播间提示，不能判定为真实直播播放',
      },
      {
        type: 'assert_screen_changes',
        intervalMs: 1500,
        minDiffRatio: 0.0005,
        label: '确认抖音直播画面在变化',
        message: '抖音直播画面变化不足，不能判定为真实直播播放',
      },
    ];
  }

  return [
    {
      type: 'assert_foreground_package',
      packageName: app.packageName,
      label: `确认仍在${app.name}`,
    },
    {
      type: 'assert_ui_text',
      any: LIVE_EVIDENCE,
      label: '确认直播间文本证据',
      message: `${app.name}未出现直播间证据，不能判定为真实直播播放`,
    },
    {
      type: 'assert_screen_changes',
      intervalMs: 1500,
      minDiffRatio: 0.0005,
      label: '确认直播画面在变化',
      message: `${app.name}直播画面变化不足，不能判定为真实直播播放`,
    },
  ];
}
