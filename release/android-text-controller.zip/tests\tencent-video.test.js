import test from 'node:test';
import assert from 'node:assert/strict';

import { buildTencentVideoPlaybackPlan } from '../server/src/skills/tencent-video.js';

test('builds a plan that taps into a real video page', () => {
  const plan = buildTencentVideoPlaybackPlan({
    app: { name: '腾讯视频', packageName: 'com.tencent.qqlive' },
    durationMs: 10_000,
    screen: { width: 1260, height: 2800 },
  });

  assert.equal(plan[0].type, 'keyevent');
  assert.equal(plan[1].type, 'tap_resource');
  assert.equal(plan[2].type, 'force_stop');
  assert.equal(plan[3].type, 'launch_app');
  assert.ok(plan.some((step) => step.type === 'tap' && step.label.includes('进入')));
  assert.ok(plan.some((step) => step.type === 'assert_foreground_package'));
  assert.ok(plan.some((step) => step.type === 'assert_screen_changes'));
  assert.equal(plan.at(-1).type, 'complete');
});
