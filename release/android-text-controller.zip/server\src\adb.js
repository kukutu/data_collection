import { execFile } from 'node:child_process';

import { config } from './config.js';

const ADB = process.env.ADB_PATH || 'adb';

function execAdb(args, options = {}) {
  return new Promise((resolve, reject) => {
    execFile(
      ADB,
      args,
      {
        encoding: options.encoding ?? 'utf8',
        timeout: options.timeoutMs ?? 15000,
        maxBuffer: options.maxBuffer ?? 20 * 1024 * 1024,
      },
      (error, stdout, stderr) => {
        if (error) {
          error.stdout = stdout;
          error.stderr = stderr;
          reject(error);
          return;
        }
        resolve({ stdout, stderr });
      },
    );
  });
}

export async function adbText(args, options) {
  const { stdout } = await execAdb(args, options);
  return String(stdout);
}

export async function listDevices() {
  const output = await adbText(['devices']);
  return output
    .split(/\r?\n/)
    .slice(1)
    .map((line) => line.trim())
    .filter(Boolean)
    .map((line) => {
      const [serial, state] = line.split(/\s+/);
      return { serial, state };
    });
}

export async function getDeviceStatus() {
  const devices = await listDevices();
  const active = devices.find((device) => device.state === 'device') || null;
  if (!active) return { connected: false, devices };

  const [model, focus, screen] = await Promise.all([
    adbText(['shell', 'getprop', 'ro.product.model']).then((value) => value.trim()).catch(() => ''),
    getCurrentFocus().catch(() => null),
    getScreenSize().catch(() => null),
  ]);

  return {
    connected: true,
    serial: active.serial,
    model,
    focus,
    screen,
    devices,
  };
}

export async function getInstalledPackages() {
  return adbText(['shell', 'pm', 'list', 'packages'], { timeoutMs: 30000 });
}

export async function getCurrentFocus() {
  const output = await adbText(['shell', 'dumpsys', 'window'], { timeoutMs: 10000 });
  const line = output
    .split(/\r?\n/)
    .find((entry) => entry.includes('mCurrentFocus=') && entry.includes('/'));
  const match = line?.match(/\s([a-zA-Z0-9_.]+)\/([^\s}]+)/);
  return match
    ? {
        packageName: match[1],
        activity: match[2],
        raw: line.trim(),
      }
    : null;
}

export async function getScreenSize() {
  const output = await adbText(['shell', 'wm', 'size']);
  const match = output.match(/Physical size:\s*(\d+)x(\d+)/);
  if (!match) return null;
  return { width: Number(match[1]), height: Number(match[2]) };
}

export async function launchPackage(packageName) {
  return adbText(['shell', 'monkey', '-p', packageName, '-c', 'android.intent.category.LAUNCHER', '1']);
}

export async function forceStopPackage(packageName) {
  return adbText(['shell', 'am', 'force-stop', packageName]);
}

export async function keyevent(code) {
  return adbText(['shell', 'input', 'keyevent', code]);
}

export async function swipe({ x1, y1, x2, y2, durationMs }) {
  return adbText([
    'shell',
    'input',
    'swipe',
    String(Math.round(x1)),
    String(Math.round(y1)),
    String(Math.round(x2)),
    String(Math.round(y2)),
    String(Math.round(durationMs)),
  ]);
}

export async function tap({ x, y }) {
  return adbText(['shell', 'input', 'tap', String(Math.round(x)), String(Math.round(y))]);
}

export async function openUri({ uri, packageName }) {
  return adbText(buildOpenUriArgs({ uri, packageName }), { timeoutMs: 20000 });
}

export function buildOpenUriArgs({ uri, packageName }) {
  const args = [
    'shell',
    'am',
    'start',
    '-a',
    'android.intent.action.VIEW',
    '-d',
    quoteAndroidShellArg(uri),
  ];
  if (packageName) args.push(packageName);
  return args;
}

export async function inputText(text) {
  return adbText(['shell', 'input', 'text', encodeAdbInputText(text)]);
}

export async function tapResource(resourceId, { optional = false } = {}) {
  let node = null;
  try {
    node = await findResourceNode(resourceId);
  } catch (error) {
    if (optional) return '';
    throw error;
  }
  if (!node) {
    if (optional) return '';
    throw new Error(`resource not found: ${resourceId}`);
  }
  return tap({ x: node.centerX, y: node.centerY });
}

export async function tapText(texts, { optional = false, partial = false } = {}) {
  let node = null;
  try {
    node = await findTextNode(texts, { partial });
  } catch (error) {
    if (optional) return '';
    throw error;
  }
  if (!node) {
    if (optional) return '';
    const label = Array.isArray(texts) ? texts.join('/') : texts;
    throw new Error(`text not found: ${label}`);
  }
  return tap({ x: node.centerX, y: node.centerY });
}

export async function tapTextInRegion(texts, { optional = false, partial = false, region } = {}) {
  let node = null;
  try {
    node = await findTextNode(texts, { partial, region });
  } catch (error) {
    if (optional) return '';
    throw error;
  }
  if (!node) {
    if (optional) return '';
    const label = Array.isArray(texts) ? texts.join('/') : texts;
    throw new Error(`text not found in region: ${label}`);
  }
  return tap({ x: node.centerX, y: node.centerY });
}

export async function assertNoSensitivePrompt() {
  let snapshot = null;
  try {
    snapshot = await getUiTextSnapshot();
  } catch (error) {
    const focus = await getCurrentFocus().catch(() => null);
    if (focus?.packageName === 'com.android.permissioncontroller') {
      throw new Error('检测到系统权限弹窗，请先在手机上手动处理后再启动自动任务');
    }
    return '';
  }
  if (!snapshot.text) return '';

  const hasAgreement = /用户协议|隐私政策|隐私协议|服务协议|个人信息|权限说明|隐私/.test(snapshot.text);
  const hasDecision = /同意并继续|同意|接受|授权|允许|不允许|不同意|始终允许|仅使用期间允许/.test(snapshot.text);
  const hasAndroidPermission = /要允许|允许.*访问|允许.*获取.*位置|访问.*位置权限|拍摄照片|录制视频|读取.*文件/.test(snapshot.text);

  if ((hasAgreement && hasDecision) || hasAndroidPermission) {
    throw new Error('检测到隐私协议或系统权限弹窗，请先在手机上手动处理后再启动自动任务');
  }

  return '';
}

export async function findResourceNode(resourceId) {
  const xml = await getUiXml();

  for (const match of xml.matchAll(/<node\b[^>]*>/g)) {
    const node = match[0];
    if (!node.includes(`resource-id="${resourceId}"`)) continue;
    const bounds = node.match(/bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/);
    if (!bounds) continue;
    const [x1, y1, x2, y2] = bounds.slice(1).map(Number);
    return {
      resourceId,
      bounds: { x1, y1, x2, y2 },
      centerX: Math.round((x1 + x2) / 2),
      centerY: Math.round((y1 + y2) / 2),
      raw: node,
    };
  }

  return null;
}

export async function findTextNode(texts, { partial = false, region } = {}) {
  const xml = await getUiXml();
  const candidates = Array.isArray(texts) ? texts : [texts];

  for (const match of xml.matchAll(/<node\b[^>]*>/g)) {
    const node = match[0];
    const text = getXmlAttr(node, 'text');
    const description = getXmlAttr(node, 'content-desc');
    const haystack = [text, description].filter(Boolean);
    const found = candidates.some((candidate) =>
      haystack.some((value) => (partial ? value.includes(candidate) : value === candidate)),
    );
    if (!found) continue;
    const bounds = node.match(/bounds="\[(\d+),(\d+)\]\[(\d+),(\d+)\]"/);
    if (!bounds) continue;
    const [x1, y1, x2, y2] = bounds.slice(1).map(Number);
    const centerX = Math.round((x1 + x2) / 2);
    const centerY = Math.round((y1 + y2) / 2);
    if (region && !isPointInRegion(centerX, centerY, region)) continue;
    return {
      texts: candidates,
      bounds: { x1, y1, x2, y2 },
      centerX,
      centerY,
      raw: node,
    };
  }

  return null;
}

function isPointInRegion(x, y, region) {
  const minX = Number(region.minX ?? region.x1 ?? 0);
  const minY = Number(region.minY ?? region.y1 ?? 0);
  const maxX = Number(region.maxX ?? region.x2 ?? Number.POSITIVE_INFINITY);
  const maxY = Number(region.maxY ?? region.y2 ?? Number.POSITIVE_INFINITY);
  return x >= minX && x <= maxX && y >= minY && y <= maxY;
}

export async function getUiTextSnapshot() {
  const xml = await getUiXml();
  const values = [];
  for (const match of xml.matchAll(/<node\b[^>]*>/g)) {
    const node = match[0];
    for (const attr of ['text', 'content-desc']) {
      const value = getXmlAttr(node, attr).trim();
      if (value) values.push(value);
    }
  }
  return {
    text: values.join('\n'),
    values,
    xml,
  };
}

export async function screenshotPng() {
  try {
    const { stdout } = await execAdb(['exec-out', 'screencap', '-p'], {
      encoding: 'buffer',
      timeoutMs: 15000,
      maxBuffer: 30 * 1024 * 1024,
    });
    return stdout;
  } catch (directError) {
    const remoteFile = '/sdcard/android-controller-screen.png';
    try {
      await adbText(['shell', 'screencap', '-p', remoteFile], { timeoutMs: 15000 });
      const { stdout } = await execAdb(['exec-out', 'cat', remoteFile], {
        encoding: 'buffer',
        timeoutMs: 15000,
        maxBuffer: 30 * 1024 * 1024,
      });
      return stdout;
    } catch (fallbackError) {
      throw new Error(`截图失败: ${fallbackError.message || directError.message}`);
    } finally {
      await adbText(['shell', 'rm', '-f', remoteFile], { timeoutMs: 5000 }).catch(() => '');
    }
  }
}

function encodeAdbInputText(text) {
  return String(text || '')
    .replace(/[^\x20-\x7E]/g, '')
    .replace(/%/g, '%25')
    .replace(/\s/g, '%s')
    .replace(/([\\'";&|<>()[\]{}$`!*?])/g, '\\$1');
}

function quoteAndroidShellArg(value) {
  return `'${String(value).replace(/'/g, "'\\''")}'`;
}

async function getUiXml() {
  let lastError = null;
  const dumpCommands = [
    ['shell', 'uiautomator', 'dump', '--compressed', config.adb.uiDumpRemoteFile],
    ['shell', 'uiautomator', 'dump', config.adb.uiDumpRemoteFile],
  ];
  for (let attempt = 0; attempt < 2; attempt += 1) {
    for (const command of dumpCommands) {
      try {
        await adbText(command, { timeoutMs: 10000 });
        return await readRemoteTextFile(config.adb.uiDumpRemoteFile);
      } catch (error) {
        lastError = error;
      }
    }
    await new Promise((resolve) => setTimeout(resolve, 500));
  }
  throw lastError;
}

async function readRemoteTextFile(remoteFile) {
  try {
    return await adbText(['exec-out', 'cat', remoteFile], { timeoutMs: 10000 });
  } catch {
    return adbText(['shell', 'cat', remoteFile], { timeoutMs: 10000 });
  }
}

function getXmlAttr(node, name) {
  const match = node.match(new RegExp(`${name}="([^"]*)"`));
  return match ? decodeXml(match[1]) : '';
}

function decodeXml(value) {
  return String(value)
    .replace(/&quot;/g, '"')
    .replace(/&apos;/g, "'")
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&amp;/g, '&');
}

export const adb = {
  getDeviceStatus,
  getInstalledPackages,
  getCurrentFocus,
  getScreenSize,
  forceStopPackage,
  launchPackage,
  keyevent,
  openUri,
  swipe,
  tap,
  tapText,
  tapTextInRegion,
  assertNoSensitivePrompt,
  inputText,
  tapResource,
  findResourceNode,
  findTextNode,
  getUiTextSnapshot,
  screenshotPng,
};
